
package escola;

public class Escola {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
