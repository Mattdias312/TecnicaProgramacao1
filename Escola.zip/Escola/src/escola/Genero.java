
package escola;

public enum Genero {
    MASCULINO,FEMININO;
}
